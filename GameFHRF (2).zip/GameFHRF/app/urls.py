
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def home(request):
    return render(request, 'home.html', {})

def telalogin(request):
    return render(request, 'login.html')

def telagamecadastrar(request):
    return render(request, 'gamecadastrar.html')

def ffaleconosco(request):
    return render(request, 'faleconosco.html')

def fcomojogar(request):
    return render(request, 'comojogar.html')

def fevento(request):
    return render(request,'eventos.html')

def fcompra(request):
    return render(request,'compra.html')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('index/', index, name='index'),
    path('game/', include('game.urls')),
    path('telalogin/', telalogin, name='telalogin'),
    path('telagamecadastrar/', telagamecadastrar, name='telagamecadastrar'),
    path('ffaleconosco/', ffaleconosco, name='ffaleconosco'),
    path('fcomojogar/', fcomojogar, name='fcomojogar'),
    path('fevento/', fevento, name='fevento'),
    path('fcompra/', fcompra, name='fcompra' )

]
