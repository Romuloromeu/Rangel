from django.contrib.auth.hashers import make_password
from django.db import models


# Create your models here.

class Game(models.Model):
    nome = models.CharField(max_length=60)
    def __str__(self):
        return self.nome


    telefone = models.CharField(max_length=15)
    @property
    def __str__(self):
        return self.telefone

    email = models.CharField(max_length=100)
    def __str__(self):
        return self.email

    senha = models.CharField(max_length=100)

    def set_password(self, senha):
        self.senha = make_password(senha)

    def save(self, *args, **kwargs):
        if self.pk is None:
            self.set_password(self.senha)
        super().save(*args, **kwargs)




from django.db import models

class Game2(models.Model):
    nome = models.CharField(max_length=100)
    telefone = models.CharField(max_length=15)
    email = models.EmailField()
    senha = models.CharField(max_length=50)
    imagens = models.ImageField(upload_to='images/', null=True, blank=True)

    def __str__(self):
        return self.nome

class Compra(models.Model):
    game = models.ForeignKey(Game2, on_delete=models.CASCADE)
    data_compra = models.DateField()
    total = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f'{self.game} - {self.data_compra}'

