from django import forms
from game.models import Game, Compra


class GameForm(forms.ModelForm):
    class Meta:
        model = Game
        fields = ['nome', 'telefone', 'email', 'senha']
        widgets = {
            'imagens': forms.FileInput(attrs={'class': 'form-control'})
        }


class CompraForm(forms.ModelForm):
    game = forms.ModelChoiceField(
        queryset=Game.objects.all(),
        label='Game',
        empty_label='Selecione um game',
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    class Meta:
        model = Compra
        fields = ['game', 'data_compra', 'total']
        widgets = {
            'data_compra': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'total': forms.NumberInput(attrs={'class': 'form-control'}),
        }
