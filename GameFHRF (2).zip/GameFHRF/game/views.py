from django.shortcuts import render, redirect
from django.db.models import Q
from .models import Game, Compra
from .forms import GameForm, CompraForm

def fcompra(request):
    if request.method == 'POST':
        form = CompraForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('administrador')
    else:
        form = CompraForm()
    return render(request, 'compra.html', {'form': form})

def cadastrar(request):
    if request.method == 'POST':
        form = GameForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = GameForm()
    return render(request, 'gamecadastrar.html', {'form': form})

def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        senha = request.POST['senha']
        try:
            game = Game.objects.get(Q(email=email) & Q(senha=senha))
            return redirect('administrador')
        except Game.DoesNotExist:
            erro = 'Email ou senha inválidos.'
            return render(request, 'login.html', {'error_message': erro})
    return render(request, 'login.html')

def administrador(request):
    return render(request, 'admin.html')

def rel_game(request):
    return render(request, 'rel_game.html')

def ffaleconosco(request):
    return render(request, 'faleconosco.html')

def fcomojogar(request):
    return render(request, 'comojogar.html')

def fevento(request):
    return render(request, 'eventos.html')

def eventos(request):
    return render(request, 'eventos.html')

def comojogar(request):
    return render(request, 'comojogar.html')
